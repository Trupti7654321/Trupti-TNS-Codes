package com.tns.onlineshopping.application;
import com.tns.onlineshopping.entities.Admin;
import com.tns.onlineshopping.entities.Customer;
import com.tns.onlineshopping.entities.Product;


import java.util.*;
public class OnlineShopping {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            List<Product> products = new ArrayList<>();
            List<Customer> customers = new ArrayList<>();
            Admin admin = new Admin(1, "Admin", "admin@example.com");

            while (true) {
                System.out.println("1. Admin Menu");
                System.out.println("2. Customer Menu");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("1. Add Product");
                        System.out.println("2. Remove Product");
                        System.out.println("3. View Products");
                        System.out.print("Choose an option: ");
                        int adminChoice = scanner.nextInt();
                        scanner.nextLine();

                        if (adminChoice == 1) {
                            System.out.print("Enter Product ID: ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter Product Name: ");
                            String name = scanner.nextLine();
                            System.out.print("Enter Product Price: ");
                            double price = scanner.nextDouble();
                            System.out.print("Enter Stock Quantity: ");
                            int stock = scanner.nextInt();
                            admin.addProduct(products, new Product(id, name, price, stock));
                        } else if (adminChoice == 2) {
                            System.out.print("Enter Product ID to remove: ");
                            int id = scanner.nextInt();
                            admin.removeProduct(products, id);
                        } else if (adminChoice == 3) {
                            products.forEach(System.out::println);
                        }
                        break;

                    case 2:
                        System.out.println("1. Register Customer");
                        System.out.println("2. View Products");
                        System.out.println("3. Add to Cart");
                        System.out.println("4. View Cart");
                        System.out.print("Choose an option: ");
                        int customerChoice = scanner.nextInt();
                        scanner.nextLine();

                        if (customerChoice == 1) {
                            System.out.print("Enter Customer ID: ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter Username: ");
                            String username = scanner.nextLine();
                            System.out.print("Enter Email: ");
                            String email = scanner.nextLine();
                            System.out.print("Enter Address: ");
                            String address = scanner.nextLine();
                            customers.add(new Customer(id, username, email, address));
                            System.out.println("Customer registered successfully!");
                        } else if (customerChoice == 2) {
                            products.forEach(System.out::println);
                        } else if (customerChoice == 3) {
                            System.out.print("Enter Customer ID: ");
                            int customerId = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter Product ID: ");
                            int productId = scanner.nextInt();
                            for (Customer customer : customers) {
                                if (customer.userId == customerId) {
                                    for (Product product : products) {
                                        if (product.getProductId() == productId) {
                                            customer.addToCart(product);
                                            System.out.println("Product added to cart!");
                                        }
                                    }
                                }
                            }
                        } else if (customerChoice == 4) {
                            System.out.print("Enter Customer ID: ");
                            int customerId = scanner.nextInt();
                            for (Customer customer : customers) {
                                if (customer.userId == customerId) {
                                    customer.viewCart();
                                }
                            }
                        }
                        break;

                    case 3:
                        System.out.println("Exiting application...");
                        scanner.close();
                        return;
                }
            }
        }
    }
