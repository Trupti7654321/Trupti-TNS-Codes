package com.tns.onlineshopping.services;

import com.tns.onlineshopping.entities.Order;

import java.util.List;

public class OrderService {
    public void updateOrderStatus(List<Order> orders, int orderId, String status) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                    order.setStatus(status);
                    System.out.println("Order status updated successfully!");
                    return;
                }
            }
            System.out.println("Order not found!");
        }

        public void viewOrders(List<Order> orders) {
            orders.forEach(System.out::println);
        }
    }
