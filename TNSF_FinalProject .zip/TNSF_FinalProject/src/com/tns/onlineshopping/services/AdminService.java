package com.tns.onlineshopping.services;
import com.tns.onlineshopping.entities.Product;

import java.util.List;

    public class AdminService {
        public void addProduct(List<Product> products, Product product) {
            products.add(product);
            System.out.println("Product added successfully!");
        }

        public void removeProduct(List<Product> products, int productId) {
            products.removeIf(product -> product.getProductId() == productId);
            System.out.println("Product removed successfully!");
        }

        public void viewProducts(List<Product> products) {
            products.forEach(System.out::println);
        }
    }

