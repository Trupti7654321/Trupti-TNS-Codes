package com.tns.onlineshopping.services;

import com.tns.onlineshopping.entities.Customer;
import com.tns.onlineshopping.entities.Product;

import java.util.List;

public class CustomerService {
    private List<Customer> customers;

    public CustomerService(List<Customer> customers) {
        this.customers = customers;
    }

    public void registerCustomer(Customer customer) {
        customers.add(customer);
        System.out.println("Customer registered successfully!");
    }

    public List<Customer> getCustomers() {
        return customers;
    }
}
