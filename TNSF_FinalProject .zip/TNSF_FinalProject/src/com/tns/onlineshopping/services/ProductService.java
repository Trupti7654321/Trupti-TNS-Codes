package com.tns.onlineshopping.services;

import com.tns.onlineshopping.entities.Product;

import java.util.ArrayList;
import java.util.List;

    public class ProductService {
        private List<Product> products = new ArrayList<>();

        public void addProduct(Product product) {
            products.add(product);
            System.out.println("Product added successfully!");
        }

        public void removeProduct(int productId) {
            products.removeIf(product -> product.getProductId() == productId);
            System.out.println("Product removed successfully!");
        }

        public List<Product> getProducts() {
            return products;
        }
    }
