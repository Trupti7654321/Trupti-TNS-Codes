package com.tns.onlineshopping.entities;


import java.util.ArrayList;
import java.util.List;

    public class ShoppingCart {
        private List<ProductQuantity> items = new ArrayList<>();

        public void addItem(Product product, int quantity) {
            items.add(new ProductQuantity(product, quantity));
        }

        public void removeItem(Product product) {
            items.removeIf(item -> item.getProduct().equals(product));
        }

        public void viewCart() {
            if (items.isEmpty()) {
                System.out.println("Shopping cart is empty.");
            } else {
                for (ProductQuantity item : items) {
                    System.out.println(item);
                }
            }
        }

        public List<ProductQuantity> getItems() {
            return items;
        }

        public void clearCart() {
            items.clear();
        }
    }

