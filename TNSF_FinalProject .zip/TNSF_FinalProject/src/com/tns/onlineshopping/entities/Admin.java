package com.tns.onlineshopping.entities;
import java.util.List;
public class Admin extends User {
        public Admin(int userId, String username, String email) {
            super(userId, username, email);
        }

        public void addProduct(List<Product> products, Product product) {
            products.add(product);
            System.out.println("Product added successfully!");
        }

        public void removeProduct(List<Product> products, int productId) {
            products.removeIf(product -> product.getProductId() == productId);
            System.out.println("Product removed successfully!");
        }
    }
