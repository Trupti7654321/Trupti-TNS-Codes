package com.tns.onlineshopping.entities;
import java.util.ArrayList;
import java.util.List;
public class Customer extends User {
        private String address;
        private List<Product> shoppingCart = new ArrayList<>();

        public Customer(int userId, String username, String email, String address) {
            super(userId, username, email);
            this.address = address;
        }

        public void addToCart(Product product) {
            shoppingCart.add(product);
        }

        public void viewCart() {
            if (shoppingCart.isEmpty()) {
                System.out.println("Shopping cart is empty.");
            } else {
                for (Product product : shoppingCart) {
                    System.out.println(product);
                }
            }
        }
    }
